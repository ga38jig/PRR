% personal.m
% Please fill in your name and matrikelnumber. Do not modify anything else.
% This should be a script file and not a function which initializes the
% strings for firstname, lastname and matnumber.
firstname='Marco'; %name z.B. firstname='Max'
lastname='Adorni'; %family name z.B. lastname='Mustermann'
matnumber='03647986'; %matrikelnumber z.B. matnumber='12345678'